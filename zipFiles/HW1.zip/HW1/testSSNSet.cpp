#include "SSNSet.h"
#include <iostream>
#include <string>
#include <cassert>
using namespace std;

int main()
{
    SSNSet ss;
    ss.add(100087);
    ss.add(671445);
    ss.add(1889000);
    
    assert(ss.size() == 3);
    
    //ss.print();
    
    
}

 
